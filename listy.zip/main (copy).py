

# lista = (input('Podaj listę imion: '))

# for imie in lista.split():
#   for kupa in imie.split(','):
#     print('cześć' ,kupa)

print(input('ile razy odpalić program?:'))
x=int(input())

dowolna = int(input)(int(input('Podaj cyfrę:')))
for cyfra in dowolna:
  if cyfra%3 == 0 and cyfra%4 == 0:
    print('hurrra')
  elif cyfra%3 == 0:
    print ('dzieli się przez 3')
  elif cyfra%4 == 0:
    print ('dzieli się przez 4')
  else:
    print('*')



# lista=range(1, 11)
# for n in lista:
#   print(n**n)






# lista=range(1, 11)
# for n in lista:
#   print (sum(lista[:n]))







# names = ["Ania", "Kasia", "Jan", "Piotr", "Paweł"]
# for name in names:
#     print("Cześć", name)

# for i in range(3):
#  for n in range(1,6):
#     print (n*"#")
    


# wiek = input('Ile masz lat: ')
# wiek=int(wiek)
# if wiek >=18 :
#   print('Jesteś osobą dorosłą')
# if wiek > 100:
#   print('200 lat')
# else:
#   print('Jestes osobą niepełnoletnią, do bycia dorosłym brakuje ci: ', 18-wiek, 'lat')
  





# DNA = 'ACTGTGCTGACTCCCGGTGCTGCCGCTGCCATAGCTAAAGCCCGGGTCCTGGTAGGCAGGCGGGAAGCAG\
# GGTGGGGGTCCCGGGTACTGGTAGGGGTAGCCCTGACCCAGAGGCGGGGGGGCAGCCGGGTGGGGCAGCG\
# GGGCCAGCGTGTCCTGAA-CGAAGTCCCACTGGAGCCACTGTTGAGGTTCAGGGTGGCGAGATCTGGCGG\
# NNNAGGGTAGGTGAGGGCCGCGGAGGGGCCTCCGGCGTTCCCCTCCCCCCCGCCCTGAAACCCGAAGCCC\
# CCACTCACTGCTGCAGAGATCCCCTGAAAACGTAGTAGCACTGCTCgagacAGGTGATCTGTTGACCTGA\
# AACCGCAGGAAGCCGTGCTTCAGCAAGCTGCTGGCGTACTTCCGGGCCT---GCCGCTCCTTGAAGCCCT\
# CCACGTGTGTGTACAGCCAGTCCACCACGTCCGCCCCTGGCCGGCACCAGCGGTCAGCCCGCAGCCTCGA\
# GGCAAGCAGCCCTGCCNNTGGCACTATCCGC-CGCGGGGACGGCCACTCACCGATGACGGCATNNGCGAT\
# GGTGATCTTGAGCCACATGCGGTCGCGGATCTCCAGTCCCGAG---GGCAGCTGCATGACCCGGACGACG\
# GCGCTCATGTCACtcaccgtcagcggcgcctcttccagCCAGCTCTGCAAAGCACAGACAGCCCCGCTTC\
# GCCCCAGCATCTGAAAGCGGGGGACTCggcAcgCTGCACCCCCAGGGGAGCCTCTGGGCAGAGCCTGCGC\
# CAGGGCGCAAGCTGGACGGTGCGTGACAGCAGGGCCCCGGCCCACTGCAGGATGCACCCCCGTGAGGCTG\
# GGGCGTGAGCAGGGGGGTTGGACAtttAGTCTCCCACTTCTACAGACACTTTTCATCAGGATCCTAGGCA\
# CAAACTGGGCTGAAACCCCACCCTGCAGACCAGGAAGTAATGAGAACAGGGCAGGCCCCTTCCCCTCNNC\
# GCATGCC-CACCCGAGAGCGCAGGCTGTTAGTCGTGTTAATGGCAGGAAGCAGAATGGAGACCTGGCCCC\
# TGCCTCTGAA-CCGTGGGTGCTCaactggctaGCCCTACGTACATCCCCTGTTCcggCCAACACACAGAC\
# ATGAGCAGGATGGGCTGCACAAGGTGGGCACGGGTGCCTGTGCACACGTCTGTGCAGGGAGTTGGGGACA\
# GGCAACACACACGTGTCACAGCCCCATGACGGggcaattgcGCCATGCTGGCTGAATGGCAGAGACGCCC\
# CTCCAAGCCTCGGTTTCTGCTGGGGCCCTCAGGAGCTGCCACTTACGTGGAGCACCAGGCACGGAGCTGG\
# TTAGTGAGGAGGAGCTGGTGCGCGTGACGGCGCTGGAGCAGGGACTCGTACCGTAGCGGGGCAGGGCNNN\
# TGTCAGTGCCGCCGTGTGGtcagcggcgatCGGCG-GGTCGATGGGCCGCACCGGGTCAGCTGGGTGNAG\
# ACACGTGGCGATGACAGGCGGACAGATGGACAGGGTGGGAGGGCAGGGTGCAGGGCACAGAGGAGAGAGG\
# CCTTCAGGCTAGGTAGGCGCCCCCTCCCCATCCCGccccGTGTGCCCCGAGGGCCACTCACCCCGTGGGA\
# CGGTGAAGTAGCTTCG-GGCGTTGGGTCCAGCACTTGGCCACAGTGAGGCTGNAAATGGCTGCAGGAACG\
# GTGGTCCCCCCGCAAGGCCCCCATGGTCCCACCTCCCTGCCTGGCCCCTCCCGCTCCAGCGCCNCCAGCC'

# DNA = DNA.upper()
# DNA = DNA.replace(' ', '')
# A = DNA.count('A')
# C = DNA.count('C')
# T = DNA.count('T')
# G = DNA.count('G')
# print('ilość aminozyn {}, ilość cytozyn {}, ilość tyminy {}, ilość guaniny {}' .format(A, C, T, G))
# print('ilosc GAGA', DNA.count('GAGA'))
# print('GAGA jest:', DNA.find('GAGA'))
# DNA = DNA.replace('GAGA', 'AGAG')
# print(DNA)
# print('7G', DNA.find('GGGGGGG'))
# print('6C', DNA.rfind('CCCCCC'))
# print('ilosc CTGAAA', DNA.count('CTGAAA'))
# print('ilosc watpliwych CTGAAA', DNA.count('CTGAA-'))
 
# DNA = DNA.replace('T','U')
# DNA = DNA.replace('-', '')
# RNA = DNA.upper()
# print(RNA)







# name = input('Podaj swoje imie :')
# print(name.title())
# print(name.isalpha())
# if name[-1] == 'a':
#   print('kobieta')
# surname = input('Podaj swoje nazwisko:')
# print(surname.title())
# print(surname.isalpha())

# mobile = input('podaj swoj nr telefonu:')
# mobile=mobile.replace('-', '')
# mobile=mobile.replace(' ','')
# print(mobile)
# print(mobile.isdigit())
# personal=name + ' '+surname + ' '+mobile
# print(personal)
# print(len(personal))
# letters = name+surname
# print(len(letters))




# dane = ' kupa jest miekka'
# print(dane)
# print(dane.strip('a'))
# print(dane.max(dane))





# sentence = 'Kurs Pythona jest prosty i przyjemny'
# lenght = len(sentence)

# print(lenght, '\n')
# print(sentence.find('prosty'))
# print(sentence[18:25])
# sentence = sentence.replace("u", 'ó')
# sentence = sentence.replace('rz','ż')
# print(sentence)






# spis_seriali = {'sex education': '8','GoT':'9','casa de papel':'7' }

# while spis_seriali:
  
#   print(list(spis_seriali.keys()))
#   pytanie = input('Jaki serial chcesz zobaczyć:')
#   print('{} dostał ocene:{}' .format(pytanie, spis_seriali[pytanie]))
#   userserial = input('jaki serial chciałbyś dodać:')
#   usermark = input('dodaj ocene serialu:')
#   spis_seriali[userserial] = float(usermark)